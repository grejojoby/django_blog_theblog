from django.apps import AppConfig


class TheblogConfig(AppConfig):
    name = 'theblog'
